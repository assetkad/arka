	// функция вывода полной информации о персоне (педагоге/учителе, как хотите)
	function fnOutFullInfo(){
		
		// если массив foundOjects пуст выводим все объекты
		if (foundOjects.length == 0) {
			data = teachers.member;
		} else {
			// если массив не пуст, значит выполнялся поиск,
			// выводим согласно выполненного поиска
			data =  foundOjects;				
		}
			
		let html = "";
		
		data.forEach(function(obj, index){
			html += "<div style='margin:15px; padding:10px; border:1px solid #c0c0c0'>";
			html += fnOutPerson(obj);
			html += fnOutEeducations(obj.educations);
			html += fnOutDisciplines(obj.disciplines);
			html += "</div>";					
		})
		
		document.querySelector("#app").innerHTML = html;
		
	}; // end fnOutFullInfo
			
	// функция вывода персональных данных
	function fnOutPerson(data) {
		let html = `
			<span>ФИО педагога:</span><b> ${data.surname} ${data.name} ${data.patronymic}</b><br/>
			<span>Занимаемая должность: </span><b>${data.post}</b><br />
			<span>Квалификационная категория: </span><b>${data.category}</b><br />
			<span>Уровень образования: </span><b>${data.level}</b>
		`;
		return html;
	
	}; // end fnOutPerson
			
	// функция вывода данных об образовании
	function fnOutEeducations(data) {
		let html = `
			<h3>Сведения об образовании</h3>
			<table>
			<tr>
			<th>Год окончания УЗ</th>
			<th>Наименование УЗ</th>
			<th>Специальность</th>
			<th>Квалификация по диплому</th>
			<th>Примечание</th>
			</tr>`;
		
		for (let i=0; i<data.length; i++) {
			html += `
				<tr>
				<th>${data[i].year}</th>
				<td>${data[i].education}</td>
				<td>${data[i].specialty}</td>
				<td>${data[i].qualification}</td>
				<td>${data[i].note}</td>
				</tr>`;
							
		};
		html += "</table>";
		return html;
	
	}; // end fnOutEeducations

	// функция вывода данных о преподаваемых дисциплинах
	function fnOutDisciplines(data) {
		let html = `
			<h3>Сведения о преподавамых дисциплинах</h3>
			<table>
			<tr>
			<th>Дисциплина</th>
			<th>Предмет</th>
			<th>Специализация</th>
			<th>Количество часов</th>
			<th>Примечание</th>
			</tr>`;
		
		for (let i=0; i<data.length; i++) {
			html += `
				<tr>
				<th>${data[i].discipline}</th>
				<td>${data[i].subject}</td>
				<td>${data[i].specialization}</td>
				<td>${data[i].hour}</td>
				<td>${data[i].note}</td>
				</tr>`;					
		};
		html += "</table>";
		return html;
	
	}; // end fnOutDisciplines